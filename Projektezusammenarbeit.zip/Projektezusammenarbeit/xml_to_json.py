import json
from bs4 import BeautifulSoup

# Lade die XML-Dateien
with open('fdb_user.xml', 'r', encoding='utf-8') as file_user:
    xml_user = file_user.read()
with open('fdb_projekte_mitarbeiter.xml', 'r', encoding='utf-8') as file_pm:
    xml_pm = file_pm.read()
with open('fdb_projekte.xml', 'r', encoding='utf-8') as file_projekte:
    xml_projekte = file_projekte.read()

# Verwende BeautifulSoup zum Parsen der XML-Dateien
soup_user = BeautifulSoup(xml_user, 'lxml')
soup_pm = BeautifulSoup(xml_pm, 'lxml')
soup_projekte = BeautifulSoup(xml_projekte, 'lxml')

# Extrahiere alle relevanten IDs aus der zweiten Datei (Projekt-Mitarbeiter)
mitarbeiter_ids = {pm.find('id_mitarbeiter').text for pm in soup_pm.find_all('projekt_mitarbeiter')}

# Extrahiere Projektdaten (titel_deu und nur von_jahr)
projekte_details = {}
projekt_user_mapping = {}  # Neue Mapping-Struktur für Projekt zu User IDs

for projekt in soup_projekte.find_all('projekt'):
    projekt_id = projekt['id']
    titel_deu = projekt.find('titel_deu').text if projekt.find('titel_deu') else ""
    
    # Hole das Jahr "von_jahr"
    jahr_von = projekt.find('von_jahr').text if projekt.find('von_jahr') else ""

    # Debugging: Ausgabe der Werte
    print(f"Projekt ID: {projekt_id}, Titel: {titel_deu}, Von Jahr: {jahr_von}")
    
    projektdetails = {
        "titel_deu": titel_deu,
        "von_jahr": jahr_von  # Nur das "von Jahr" wird gespeichert
    }
    
    # Speichere Projektdetails
    projekte_details[projekt_id] = projektdetails

    # Finde alle User, die in diesem Projekt sind und speichere deren IDs
    user_ids = [pm.find('id_mitarbeiter').text for pm in soup_pm.find_all('projekt_mitarbeiter') if pm.find('id_projekt').text == projekt_id]
    projekt_user_mapping[projekt_id] = user_ids

# Erstelle ein Dictionary für die Forscher mit ihren Projekten
researchers = {}

# Füge die Forscher-Daten hinzu
for user in soup_user.find_all('user'):
    user_id = user['id']
    
    if user_id in mitarbeiter_ids:
        # Extrahiere die Benutzerinformationen
        user_name = user.find('user_name').text
        vorname = user.find('vorname').text
        nachname = user.find('nachname').text
        funktion = user.find('funktion').text if user.find('funktion') else ""
        institut = user.find('institut').text if user.find('institut') else ""
        
        # Initialisiere eine Liste für die Projekt-IDs
        projekt_ids = []
        
        # Finde alle Projekte, bei denen der Mitarbeiter beteiligt ist
        for pm in soup_pm.find_all('projekt_mitarbeiter'):
            if pm.find('id_mitarbeiter').text == user_id:
                projekt_id = pm.find('id_projekt').text
                projekt_ids.append(projekt_id)
        
        # Speichere die Forscher-Daten
        researchers[user_id] = {
            "user_id": user_id,
            "user_name": user_name,
            "vorname": vorname,
            "nachname": nachname,
            "funktion": funktion,
            "institut": institut,
            "projekt_ids": ",".join(projekt_ids),  # Projekte als kommagetrennte Liste
        }

# Erstelle die Verbindungen zwischen Forschern, basierend auf gemeinsamen Projekten
connections = []
for pm in soup_pm.find_all('projekt_mitarbeiter'):
    id_mitarbeiter = pm.find('id_mitarbeiter').text
    id_projekt = pm.find('id_projekt').text

    # Finde alle Mitarbeiter, die am gleichen Projekt beteiligt sind
    mitarbeiter_im_projekt = [pm2.find('id_mitarbeiter').text for pm2 in soup_pm.find_all('projekt_mitarbeiter') if pm2.find('id_projekt').text == id_projekt]

    # Erstelle Verbindungen zwischen den Mitarbeitern
    for source_id in mitarbeiter_im_projekt:
        for target_id in mitarbeiter_im_projekt:
            if source_id != target_id:
                connections.append({
                    "source": source_id,
                    "target": target_id,
                    "value": 1  # Hier können weitere Kriterien oder Berechnungen folgen
                })

# Erstelle die finale JSON-Struktur
json_data = {
    "researchers": list(researchers.values()),
    "projects": []
}

# Füge Projektdetails hinzu
for projekt_id, details in projekte_details.items():
    projektdetails = details.copy()
    projektdetails["projekt_id"] = projekt_id  # Hier steht nur die Projekt-ID
    json_data["projects"].append(projektdetails)

# Erstelle die Verbindungen zwischen Forschern und Projekten
json_data["connections"] = connections

# Speichere das JSON-Objekt in einer Datei
with open('forschende_mit_verbindungen_mit_projekten_und_jahren.json', 'w', encoding='utf-8') as json_file:
    json.dump(json_data, json_file, ensure_ascii=False, indent=4)

print("JSON-Datei 'forschende_mit_verbindungen_mit_projekten_und_jahren.json' wurde erfolgreich erstellt!")
